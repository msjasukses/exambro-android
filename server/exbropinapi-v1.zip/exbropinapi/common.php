<?php
/**
 * ExBro / CBT Cyber Edu - fungsi bersama untuk verify-pin.php dan admin.php.
 *
 * File ini tidak menghasilkan output dan menjawab 404 bila dibuka langsung.
 */
declare(strict_types=1);

if (realpath(__FILE__) === realpath((string) ($_SERVER['SCRIPT_FILENAME'] ?? ''))) {
    http_response_code(404);
    exit;
}

const EXBRO_PIN_STORE = __DIR__ . '/pin-store.php';
const EXBRO_PIN_MIN = 4;
const EXBRO_PIN_MAX = 8;

/** Isi config.php, atau array kosong bila file belum ada. */
function exbro_config(): array
{
    static $config = null;
    if ($config === null) {
        $file = __DIR__ . '/config.php';
        $loaded = is_file($file) ? require $file : [];
        $config = is_array($loaded) ? $loaded : [];
    }
    return $config;
}

function exbro_is_placeholder(string $value): bool
{
    return $value === '' || strpos($value, 'GANTI_') === 0;
}

/**
 * Isi pin-store.php. Formatnya baris PHP yang langsung exit, diikuti JSON, jadi
 * dibuka lewat browser hanya menghasilkan 404 kosong. Dibaca sebagai teks biasa
 * (bukan require) agar PIN baru tidak tertahan cache opcache.
 */
function exbro_read_store(): ?array
{
    if (!is_file(EXBRO_PIN_STORE)) {
        return null;
    }
    $raw = @file_get_contents(EXBRO_PIN_STORE);
    if ($raw === false) {
        return null;
    }
    $pos = strpos($raw, '?>');
    if ($pos === false) {
        return null;
    }
    $data = json_decode(trim(substr($raw, $pos + 2)), true);
    return is_array($data) ? $data : null;
}

/**
 * PIN yang berlaku saat ini.
 *
 * @return array{pin: string, changed_at: ?int, source: string}
 *         source "store" bila pernah diganti lewat admin.php, "config" bila masih
 *         memakai exit_pin dari config.php.
 */
function exbro_current_pin(): array
{
    $store = exbro_read_store();
    if ($store !== null && isset($store['pin']) && is_string($store['pin']) && $store['pin'] !== '') {
        return ['pin' => $store['pin'], 'changed_at' => (int) ($store['changed_at'] ?? 0), 'source' => 'store'];
    }
    return ['pin' => (string) (exbro_config()['exit_pin'] ?? ''), 'changed_at' => null, 'source' => 'config'];
}

/** Menyimpan PIN baru secara atomik (tulis file sementara lalu rename). */
function exbro_save_pin(string $pin): bool
{
    $payload = "<?php http_response_code(404); exit; ?>\n"
        . json_encode(['pin' => $pin, 'changed_at' => time()]) . "\n";

    // Berakhiran .php agar, bila rename gagal dan file tertinggal, isinya tetap
    // tidak bisa dibaca lewat web.
    $tmp = __DIR__ . '/pin-store.tmp-' . bin2hex(random_bytes(6)) . '.php';
    if (@file_put_contents($tmp, $payload, LOCK_EX) === false) {
        return false;
    }
    @chmod($tmp, 0640);
    if (!@rename($tmp, EXBRO_PIN_STORE)) {
        @unlink($tmp);
        return false;
    }
    return true;
}

// --- Catatan percobaan gagal (dipakai pembatasan PIN salah & login admin) ---------

/**
 * Membuka catatan kegagalan dengan kunci eksklusif dan membuang entri yang sudah
 * lewat jendela waktu. Wajib ditutup dengan exbro_failures_close().
 */
function exbro_failures_open(int $windowSeconds): ?array
{
    $file = sys_get_temp_dir() . DIRECTORY_SEPARATOR . 'exbropinapi-failures.json';
    $handle = @fopen($file, 'c+');
    if ($handle === false) {
        return null;
    }
    flock($handle, LOCK_EX);
    $raw = stream_get_contents($handle);
    $data = json_decode($raw === false ? '' : $raw, true);
    if (!is_array($data)) {
        $data = [];
    }

    $now = time();
    foreach ($data as $key => $stamps) {
        $data[$key] = array_values(array_filter(
            (array) $stamps,
            static function ($t) use ($now, $windowSeconds): bool {
                return is_int($t) && $t > $now - $windowSeconds;
            }
        ));
        if ($data[$key] === []) {
            unset($data[$key]);
        }
    }

    return ['handle' => $handle, 'data' => $data, 'now' => $now];
}

function exbro_failures_count(array $state, string $key): int
{
    return count($state['data'][$key] ?? []);
}

function exbro_failures_add(array &$state, string $key): void
{
    $state['data'][$key][] = $state['now'];
}

function exbro_failures_clear(array &$state, string $key): void
{
    unset($state['data'][$key]);
}

function exbro_failures_close(array $state): void
{
    $handle = $state['handle'];
    ftruncate($handle, 0);
    rewind($handle);
    fwrite($handle, (string) json_encode($state['data']));
    fflush($handle);
    flock($handle, LOCK_UN);
    fclose($handle);
}
