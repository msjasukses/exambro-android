<?php
/**
 * ExBro / CBT Cyber Edu - verifikasi PIN keluar.
 *
 * Letakkan folder exbro-pin-api di web root server CBT sehingga dapat diakses di
 *   http(s)://<host-link-ujian>/exbro-pin-api/verify-pin.php
 *
 * Protokol:
 *   Request  POST application/json
 *            {"nonce": "<32 hex>", "device": "<id perangkat>", "pin_hmac": "<64 hex>"}
 *            pin_hmac = HMAC-SHA256(api_key, nonce + "|" + pin)
 *   Response 200 {"result": "valid"|"invalid",
 *                 "sig": HMAC-SHA256(api_key, nonce + "|" + result)}
 *            400 payload tidak valid, 405 bukan POST, 429 terlalu banyak PIN salah,
 *            503 belum dikonfigurasi.
 *
 * PIN tidak pernah dikirim apa adanya dan jawaban ditandatangani memakai nonce dari
 * aplikasi, sehingga tetap aman walau koneksinya HTTP biasa di jaringan sekolah.
 */
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

function respond(int $status, array $body): void
{
    http_response_code($status);
    echo json_encode($body);
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    respond(405, ['error' => 'method_not_allowed']);
}

$configFile = __DIR__ . '/config.php';
if (!is_file($configFile)) {
    respond(503, ['error' => 'not_configured']);
}
$config = require $configFile;

$apiKey = (string) ($config['api_key'] ?? '');
$exitPin = (string) ($config['exit_pin'] ?? '');
$isPlaceholder = static function (string $value): bool {
    return $value === '' || strpos($value, 'GANTI_') === 0;
};
if ($isPlaceholder($apiKey) || $isPlaceholder($exitPin)) {
    respond(503, ['error' => 'not_configured']);
}

$maxPerDevice = (int) ($config['max_failures_per_device'] ?? 10);
$maxPerIp = (int) ($config['max_failures_per_ip'] ?? 300);
$window = (int) ($config['window_seconds'] ?? 300);

$payload = json_decode((string) file_get_contents('php://input'), true);
$field = static function ($payload, string $name): string {
    return (is_array($payload) && isset($payload[$name]) && is_string($payload[$name]))
        ? $payload[$name]
        : '';
};
$nonce = $field($payload, 'nonce');
$device = $field($payload, 'device');
$pinHmac = $field($payload, 'pin_hmac');

if (!preg_match('/^[0-9a-f]{32}$/', $nonce)
    || !preg_match('/^[A-Za-z0-9-]{8,64}$/', $device)
    || !preg_match('/^[0-9a-f]{64}$/', $pinHmac)) {
    respond(400, ['error' => 'bad_request']);
}

// --- Pembatasan PIN salah per perangkat dan per IP -------------------------
// Per perangkat supaya satu siswa yang menebak-nebak PIN tidak mengunci HP lain
// yang keluar ke internet lewat IP publik yang sama.
$store = sys_get_temp_dir() . DIRECTORY_SEPARATOR . 'exbro-pin-api-failures.json';
$handle = fopen($store, 'c+');
if ($handle === false) {
    respond(503, ['error' => 'storage_unavailable']);
}
flock($handle, LOCK_EX);
$raw = stream_get_contents($handle);
$failures = json_decode($raw === false ? '' : $raw, true);
if (!is_array($failures)) {
    $failures = [];
}

$now = time();
foreach ($failures as $key => $stamps) {
    $failures[$key] = array_values(array_filter(
        (array) $stamps,
        static function ($t) use ($now, $window): bool {
            return is_int($t) && $t > $now - $window;
        }
    ));
    if ($failures[$key] === []) {
        unset($failures[$key]);
    }
}

$deviceKey = 'd:' . $device;
$ipKey = 'i:' . (string) ($_SERVER['REMOTE_ADDR'] ?? 'unknown');

$save = static function () use ($handle, &$failures): void {
    ftruncate($handle, 0);
    rewind($handle);
    fwrite($handle, (string) json_encode($failures));
    fflush($handle);
    flock($handle, LOCK_UN);
    fclose($handle);
};

if (count($failures[$deviceKey] ?? []) >= $maxPerDevice
    || count($failures[$ipKey] ?? []) >= $maxPerIp) {
    $save();
    respond(429, ['error' => 'too_many_attempts']);
}

// --- Verifikasi ---------------------------------------------------------------
$expected = hash_hmac('sha256', $nonce . '|' . $exitPin, $apiKey);
$valid = hash_equals($expected, $pinHmac);

if ($valid) {
    unset($failures[$deviceKey]);
} else {
    $failures[$deviceKey][] = $now;
    $failures[$ipKey][] = $now;
}
$save();

$result = $valid ? 'valid' : 'invalid';
respond(200, [
    'result' => $result,
    'sig' => hash_hmac('sha256', $nonce . '|' . $result, $apiKey),
]);
