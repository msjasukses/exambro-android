<?php
/**
 * Salin menjadi config.php lalu isi. File ini hanya mengembalikan array dan tidak
 * menghasilkan output apa pun bila dibuka langsung lewat browser.
 */
return [
    // Harus SAMA persis dengan api.key di exbro-api.properties pada proyek aplikasi.
    'api_key' => 'GANTI_DENGAN_API_KEY',

    // PIN keluar awal untuk semua HP. Setelah PIN diganti lewat admin.php, PIN baru
    // disimpan di pin-store.php dan nilai ini tidak dipakai lagi.
    // Selama masih GANTI_... dan belum ada PIN dari admin.php, endpoint menjawab 503
    // dan aplikasi memakai PIN lokal.
    'exit_pin' => 'GANTI_DENGAN_PIN',

    // Hash password untuk halaman admin.php (ganti PIN). Biarkan kosong, lalu buka
    // admin.php: halaman itu akan membuatkan baris hash untuk ditempel di sini.
    'admin_password_hash' => '',

    // Batas PIN salah dalam window_seconds sebelum dijawab 429.
    'max_failures_per_device' => 10,
    'max_failures_per_ip' => 300,
    'window_seconds' => 300,
];
