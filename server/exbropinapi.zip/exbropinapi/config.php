<?php
/**
 * Salin menjadi config.php lalu isi. File ini hanya mengembalikan array dan tidak
 * menghasilkan output apa pun bila dibuka langsung lewat browser.
 */
return [
    // Harus SAMA persis dengan api.key di exbro-api.properties pada proyek aplikasi.
    'api_key' => 'a6a74326eeee1250c40fb783cac18abbb91d53591574a29675263ad92c8f9898',

    // PIN keluar utama untuk semua HP. Bisa diganti kapan saja tanpa build ulang APK.
    // Selama masih GANTI_..., endpoint menjawab 503 dan aplikasi memakai PIN lokal.
    'exit_pin' => 'GANTI_DENGAN_PIN',

    // Batas PIN salah dalam window_seconds sebelum dijawab 429.
    'max_failures_per_device' => 10,
    'max_failures_per_ip' => 300,
    'window_seconds' => 300,
];
